﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    public GameManager gameManager;
    public float speed;

    public Animator anim;
    public float turnSpeed;

    public float rotateAmount;
    public float rotateSpeed;

    public float timeTillObjects;

    public GameObject sun;
    public GameObject obstacle;

    float time;

    // Update is called once per frame
    void FixedUpdate()
    {
        //time = timeTillObjects;
        if(time < Time.time)
        {
            Vector3 spawnPoint = transform.position;
            spawnPoint.x += Random.Range(-7.5f, 7.5f);
            spawnPoint.z += Random.Range(15, 25);
            Instantiate(sun, spawnPoint, Quaternion.identity);

            Vector3 spawnPoint2 = transform.position;
            spawnPoint2.x += Random.Range(-7.5f, 7.5f);
            spawnPoint2.z += Random.Range(15, 25);
            Instantiate(obstacle, spawnPoint2, Quaternion.identity);

            time = Time.time + timeTillObjects;
        }

        float horizontal = Input.GetAxisRaw("Horizontal");
        float vertical = Input.GetAxisRaw("Vertical");

        Vector3 movement = new Vector3(horizontal * turnSpeed, 0, speed);

        transform.Translate(movement * Time.deltaTime);

        if(horizontal > 0)
        {
            //Rotate Right
            anim.SetBool("right", true);
            anim.SetBool("left", false);
        }
        else if(horizontal < 0)
        {
            //Rotate Left
            anim.SetBool("left", true);
            anim.SetBool("right", false);
        }
        else if(horizontal == 0)
        {
            //Dont Rotate
            anim.SetBool("left", false);
            anim.SetBool("right", false);
        }

        Vector3 currentPos = transform.position;
        currentPos.y = 1;
        transform.position = currentPos;
    }

    void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.tag == "Sun")
        {
            gameManager.timeTillDeath += 5;
            Debug.Log("Trigger Sun");
            Destroy(other.gameObject);
        }
        else if(other.gameObject.tag == "obstacle")
        {
            Application.Quit();
        }
    }
}
