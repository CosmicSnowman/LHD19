﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering.PostProcessing;

public class GameManager : MonoBehaviour
{
    public float timeTillDeath;

    public float vignette;

    float originalTime;

    Vignette vignetteLayer;

    // Start is called before the first frame update
    void Start()
    {
        originalTime = timeTillDeath;
        PostProcessVolume volume = gameObject.GetComponent<PostProcessVolume>();
        volume.profile.TryGetSettings(out vignetteLayer);
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        vignette = 1 - (timeTillDeath/originalTime);

        timeTillDeath -= Time.deltaTime;

        vignetteLayer.intensity.value = vignette;

        if(timeTillDeath < 0)
        {
            Application.Quit();
        }
    }
}
