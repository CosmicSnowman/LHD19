# !Light

We attempted to recreate Google Chrome's standard incognito new tab page.
No references, google, or testing your code.
