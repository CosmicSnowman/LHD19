# !Light

We attempted to recreate Flappy Bird in Scratch in 20 minutes.
No references, google, testing your code, or premade assets (except the Scratch cat).
