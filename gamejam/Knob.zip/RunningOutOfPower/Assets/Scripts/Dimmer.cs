﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dimmer : MonoBehaviour
{
	bool quit = false;
	public int power;
	Camera cam;
	
	public int maxpower = 1000;
	public float color = 0.625f;
	
    // Start is called before the first frame update
    void Start()
    {
        power = maxpower;
		cam = GetComponent<Camera>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
	
	void FixedUpdate() {
		if(quit) return;
		if(power > maxpower) power = maxpower;
		power -= 1;
		cam.backgroundColor = new Color(power*color/maxpower, power*color/maxpower, power*color/maxpower);
		if(power < 1) {
			quit = true;
			cam.backgroundColor = Color.red;
			Application.Quit();
		}
	}
}
