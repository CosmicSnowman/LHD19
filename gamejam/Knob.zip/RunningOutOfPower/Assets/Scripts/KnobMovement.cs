﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KnobMovement : MonoBehaviour
{
	bool selected = false;
	float thrust = 5f;
	
	//Components
	Transform transform;
	Rigidbody2D rb;
	
	// Start is called before the first frame update
	void Start()
	{
		transform = GetComponent<Transform>();
		rb = GetComponent<Rigidbody2D>();
		print("started");
	}

	// Update is called once per frame
	void Update()
	{
		if(selected) {
			if(Input.GetMouseButtonUp(0)) selected = false;
			float xdiff = Input.mousePosition.x - transform.position.x;
			float ydiff = Input.mousePosition.y - transform.position.y;
			rb.AddForce(new Vector2(xdiff/thrust, ydiff/thrust));
		}
	}
	
	void OnMouseOver() {
		if(Input.GetMouseButtonDown(0)) {
			selected = true;
		}
	}
}
